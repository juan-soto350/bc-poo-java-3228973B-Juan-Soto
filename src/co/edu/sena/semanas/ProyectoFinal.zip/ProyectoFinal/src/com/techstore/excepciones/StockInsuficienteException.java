package co.edu.sena.semanas.ProyectoFinal.src.com.techstore.excepciones;



//Excepción lanzada cuando no hay suficiente stock para realizar una venta.

public class StockInsuficienteException extends Exception {
    
    private int stockDisponible;
    private int cantidadSolicitada;
    
    // Constructor con mensaje personalizado.
     
    public StockInsuficienteException(String mensaje) {
        super(mensaje);
    }
    
    // Constructor con detalles de stock.
     
    public StockInsuficienteException(String mensaje, int stockDisponible, int cantidadSolicitada) {
        super(mensaje);
        this.stockDisponible = stockDisponible;
        this.cantidadSolicitada = cantidadSolicitada;
    }
    
    public int getStockDisponible() {
        return stockDisponible;
    }
    
    public int getCantidadSolicitada() {
        return cantidadSolicitada;
    }
}