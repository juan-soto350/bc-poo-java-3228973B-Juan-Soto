package co.edu.sena.semanas.ProyectoFinal.src.com.techstore.modelo;


/**
 * Clase que representa un smartphone en TechStore.
 * Hereda de Producto.
 */
public class Smartphone extends Producto {
    private String sistemaOperativo;
    private double pantallaPulgadas;
    private int camaraMP;
    private int bateriaMAh;
    private boolean es5G;

    // Constructor de Smartphone.
     
    public Smartphone(String codigo, String marca, String modelo, double precio, int stock, 
                      int garantiaMeses, String sistemaOperativo, double pantallaPulgadas, 
                      int camaraMP, int bateriaMAh, boolean es5G) {
        super(codigo, marca, modelo, precio, stock, garantiaMeses);
        this.sistemaOperativo = sistemaOperativo;
        this.pantallaPulgadas = pantallaPulgadas;
        this.camaraMP = camaraMP;
        this.bateriaMAh = bateriaMAh;
        this.es5G = es5G;
    }

    public String getSistemaOperativo() {
        return sistemaOperativo;
    }

    public double getPantallaPulgadas() {
        return pantallaPulgadas;
    }

    public int getCamaraMP() {
        return camaraMP;
    }

    public int getBateriaMAh() {
        return bateriaMAh;
    }

    public boolean isEs5G() {
        return es5G;
    }

    @Override
    public void mostrarEspecificaciones() {
        System.out.println("=== ESPECIFICACIONES DEL SMARTPHONE ===");
        System.out.println(super.toString());
        System.out.println("Sistema Operativo: " + sistemaOperativo);
        System.out.println("Pantalla: " + pantallaPulgadas + " pulgadas");
        System.out.println("Cámara: " + camaraMP + " MP");
        System.out.println("Batería: " + bateriaMAh + " mAh");
        System.out.println("5G: " + (es5G ? "Sí" : "No"));
        System.out.println("Garantía: " + getGarantiaMeses() + " meses");
    }
}