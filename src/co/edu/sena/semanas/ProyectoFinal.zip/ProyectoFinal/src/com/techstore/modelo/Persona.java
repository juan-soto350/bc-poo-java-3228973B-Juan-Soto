package co.edu.sena.semanas.ProyectoFinal.src.com.techstore.modelo;

/**
 * Clase abstracta que representa una persona en el sistema TechStore.
 * Sirve como clase base para Cliente y Empleado.
 */ 
public abstract class Persona {
    private String id;
    private String nombre;
    private String telefono;
    private String email;

    // Constructor de la clase Persona.
     
     
    public Persona(String id, String nombre, String telefono, String email) {
        if (id == null || id.trim().isEmpty()) {
            throw new IllegalArgumentException("El ID no puede estar vacío");
        }
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre no puede estar vacío");
        }
        if (email == null || !email.contains("@")) {
            throw new IllegalArgumentException("El email debe ser válido");
        }
        
        this.id = id;
        this.nombre = nombre;
        this.telefono = telefono;
        this.email = email;
    }

    // Getters y Setters con validaciones
    public String getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre no puede estar vacío");
        }
        this.nombre = nombre;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        if (email == null || !email.contains("@")) {
            throw new IllegalArgumentException("El email debe ser válido");
        }
        this.email = email;
    }

    /**
     * Método abstracto para mostrar información.
     * Debe ser implementado por las clases hijas.
     */
    public abstract void mostrarInformacion();

    @Override
    public String toString() {
        return "ID: " + id + ", Nombre: " + nombre + ", Teléfono: " + telefono + ", Email: " + email;
    }
}