package co.edu.sena.semanas.ProyectoFinal.src.com.techstore.modelo;

/**
 * Clase que representa un cliente de TechStore.
 * Hereda de Persona.
 */
public class Cliente extends Persona {
    private String tipoCliente; // "Regular", "VIP", "Premium"
    private double descuentoAplicable;
    private int puntosAcumulados;

    // Constructor de Cliente.
     
    public Cliente(String id, String nombre, String telefono, String email, String tipoCliente) {
        super(id, nombre, telefono, email);
        this.tipoCliente = tipoCliente;
        this.puntosAcumulados = 0;
        calcularDescuento();
    }

    // Calcula el descuento según el tipo de cliente.
     
    private void calcularDescuento() {
        switch (tipoCliente) {
            case "VIP":
                this.descuentoAplicable = 0.15;
                break;
            case "Premium":
                this.descuentoAplicable = 0.25;
                break;
            default:
                this.descuentoAplicable = 0.0;
        }
    }

    public String getTipoCliente() {
        return tipoCliente;
    }

    public void setTipoCliente(String tipoCliente) {
        this.tipoCliente = tipoCliente;
        calcularDescuento();
    }

    public double getDescuentoAplicable() {
        return descuentoAplicable;
    }

    public int getPuntosAcumulados() {
        return puntosAcumulados;
    }

    public void agregarPuntos(int puntos) {
        if (puntos > 0) {
            this.puntosAcumulados += puntos;
        }
    }

    @Override
    public void mostrarInformacion() {
        System.out.println("=== INFORMACIÓN DEL CLIENTE ===");
        System.out.println(super.toString());
        System.out.println("Tipo: " + tipoCliente);
        System.out.println("Descuento: " + (descuentoAplicable * 100) + "%");
        System.out.println("Puntos Acumulados: " + puntosAcumulados);
    }
}