package co.edu.sena.semanas.ProyectoFinal.src.com.techstore.modelo;
/**
 * Clase abstracta que representa un producto tecnológico.
 * Implementa la interfaz Cotizable.
 * 
 * @author Juan Esteban Soto Perez
 * @version 1.0
 * @since Semana 09
 */
public abstract class Producto implements Cotizable {
    private String codigo;
    private String marca;
    private String modelo;
    private double precio;
    private int stock;
    private int garantiaMeses;

    /**
     * Constructor de Producto.
     * 
     * @param codigo Código único del producto
     * @param marca Marca del producto
     * @param modelo Modelo del producto
     * @param precio Precio base
     * @param stock Cantidad disponible
     * @param garantiaMeses Meses de garantía
     */
    public Producto(String codigo, String marca, String modelo, double precio, int stock, int garantiaMeses) {
        if (codigo == null || codigo.trim().isEmpty()) {
            throw new IllegalArgumentException("El código no puede estar vacío");
        }
        if (precio < 0) {
            throw new IllegalArgumentException("El precio no puede ser negativo");
        }
        if (stock < 0) {
            throw new IllegalArgumentException("El stock no puede ser negativo");
        }
        
        this.codigo = codigo;
        this.marca = marca;
        this.modelo = modelo;
        this.precio = precio;
        this.stock = stock;
        this.garantiaMeses = garantiaMeses;
    }

    public String getCodigo() {
        return codigo;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        if (precio < 0) {
            throw new IllegalArgumentException("El precio no puede ser negativo");
        }
        this.precio = precio;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        if (stock < 0) {
            throw new IllegalArgumentException("El stock no puede ser negativo");
        }
        this.stock = stock;
    }

    public int getGarantiaMeses() {
        return garantiaMeses;
    }

    public void setGarantiaMeses(int garantiaMeses) {
        this.garantiaMeses = garantiaMeses;
    }

    /**
     * Verifica si hay stock disponible.
     * 
     * @return true si hay stock, false en caso contrario
     */
    public boolean hayDisponibilidad() {
        return stock > 0;
    }

    /**
     * Reduce el stock en la cantidad indicada.
     * 
     * @param cantidad Cantidad a reducir
     * @return true si se pudo reducir, false si no hay suficiente stock
     */
    public boolean reducirStock(int cantidad) {
        if (cantidad > stock) {
            return false;
        }
        stock -= cantidad;
        return true;
    }

    @Override
    public double calcularPrecioFinal(double descuento) {
        return precio * (1 - descuento);
    }

    /**
     * Método abstracto para mostrar especificaciones técnicas.
     * Debe ser implementado por las clases hijas.
     */
    public abstract void mostrarEspecificaciones();

    @Override
    public String toString() {
        return "Código: " + codigo + ", Marca: " + marca + ", Modelo: " + modelo + 
               ", Precio: $" + String.format("%,.2f", precio) + ", Stock: " + stock;
    }
} 
