package co.edu.sena.semanas.ProyectoFinal.src.com.techstore.modelo;

/**
 * Clase que representa un computador en TechStore.
 * Hereda de Producto.
 */
public class Computador extends Producto {
    private String procesador;
    private int ramGB;
    private int almacenamientoGB;
    private String tarjetaGrafica;
    private String tipo; // "Laptop", "Desktop", "All-in-One"

    // Constructor de Computador.
     
    public Computador(String codigo, String marca, String modelo, double precio, int stock, 
                      int garantiaMeses, String procesador, int ramGB, int almacenamientoGB, 
                      String tarjetaGrafica, String tipo) {
        super(codigo, marca, modelo, precio, stock, garantiaMeses);
        this.procesador = procesador;
        this.ramGB = ramGB;
        this.almacenamientoGB = almacenamientoGB;
        this.tarjetaGrafica = tarjetaGrafica;
        this.tipo = tipo;
    }

    public String getProcesador() {
        return procesador;
    }

    public int getRamGB() {
        return ramGB;
    }

    public int getAlmacenamientoGB() {
        return almacenamientoGB;
    }

    public String getTarjetaGrafica() {
        return tarjetaGrafica;
    }

    public String getTipo() {
        return tipo;
    }

    @Override
    public void mostrarEspecificaciones() {
        System.out.println("=== ESPECIFICACIONES DEL COMPUTADOR ===");
        System.out.println(super.toString());
        System.out.println("Tipo: " + tipo);
        System.out.println("Procesador: " + procesador);
        System.out.println("RAM: " + ramGB + " GB");
        System.out.println("Almacenamiento: " + almacenamientoGB + " GB");
        System.out.println("Tarjeta Gráfica: " + tarjetaGrafica);
        System.out.println("Garantía: " + getGarantiaMeses() + " meses");
    }
}