package co.edu.sena.semanas.ProyectoFinal.src.com.techstore.excepciones;

// Excepción lanzada cuando un producto no es encontrado en el sistema.

public class ProductoNoEncontradoException extends Exception {
    
    // Constructor con mensaje personalizado.
    
    public ProductoNoEncontradoException(String mensaje) {
        super(mensaje);
    }
    
    // Constructor con mensaje y causa.
     
    public ProductoNoEncontradoException(String mensaje, Throwable causa) {
        super(mensaje, causa);
    }
}
