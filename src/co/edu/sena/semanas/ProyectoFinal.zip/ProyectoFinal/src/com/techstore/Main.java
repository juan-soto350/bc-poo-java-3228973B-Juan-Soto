package co.edu.sena.semanas.ProyectoFinal.src.com.techstore;

import co.edu.sena.semanas.ProyectoFinal.src.com.techstore.modelo.*;
import co.edu.sena.semanas.ProyectoFinal.src.com.techstore.servicio.GestorTienda;
import co.edu.sena.semanas.ProyectoFinal.src.com.techstore.excepciones.*;
import java.util.*;

public class Main {
    private static GestorTienda gestor = new GestorTienda();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("╔════════════════════════════════╗");
        System.out.println("║   BIENVENIDO A TECHSTORE       ║");
        System.out.println("╚════════════════════════════════╝\n");

        boolean continuar = true;
        while (continuar) {
            mostrarMenuPrincipal();
            int opcion = leerOpcion();

            try {
                switch (opcion) {
                    case 1: menuProductos(); break;
                    case 2: menuClientes(); break;
                    case 3: registrarEmpleado(); break;
                    case 4: realizarVenta(); break;
                    case 5: gestor.listarVentas(); break;
                    case 6: gestor.mostrarEstadisticas(); break;
                    case 0:
                        System.out.println("\n¡Gracias por usar TechStore!\n");
                        continuar = false;
                        break;
                    default:
                        System.out.println("⚠ Opción inválida");
                }
            } catch (Exception e) {
                System.out.println(" Error: " + e.getMessage());
            }

            if (continuar) {
                System.out.println("\nPresione Enter para continuar...");
                scanner.nextLine();
            }
        }
        scanner.close();
    }

    private static void mostrarMenuPrincipal() {
        System.out.println("\n═══ MENÚ PRINCIPAL ═══");
        System.out.println("1. Gestión de Productos");
        System.out.println("2. Gestión de Clientes");
        System.out.println("3. Registrar Empleado");
        System.out.println("4. Realizar Venta");
        System.out.println("5. Ver Ventas");
        System.out.println("6. Estadísticas");
        System.out.println("0. Salir");
        System.out.print("Opción: ");
    }

    private static void menuProductos() {
        System.out.println("\n=== PRODUCTOS ===");
        System.out.println("1. Agregar Computador");
        System.out.println("2. Agregar Smartphone");
        System.out.println("3. Buscar producto");
        System.out.println("4. Listar todos");
        System.out.println("5. Actualizar precio");
        System.out.println("6. Eliminar producto");
        System.out.println("7. Filtrar por marca");
        System.out.print("Opción: ");

        int opcion = leerOpcion();
        try {
            switch (opcion) {
                case 1: agregarComputador(); break;
                case 2: agregarSmartphone(); break;
                case 3: buscarProducto(); break;
                case 4: gestor.listarTodosLosProductos(); break;
                case 5: actualizarPrecio(); break;
                case 6: eliminarProducto(); break;
                case 7: filtrarPorMarca(); break;
            }
        } catch (Exception e) {
            System.out.println(" " + e.getMessage());
        }
    }

    private static void agregarComputador() {
        System.out.println("\n--- Nuevo Computador ---");
        System.out.print("Código: "); String codigo = scanner.nextLine();
        System.out.print("Marca: "); String marca = scanner.nextLine();
        System.out.print("Modelo: "); String modelo = scanner.nextLine();
        System.out.print("Precio: "); double precio = Double.parseDouble(scanner.nextLine());
        System.out.print("Stock: "); int stock = Integer.parseInt(scanner.nextLine());
        System.out.print("Garantía (meses): "); int garantia = Integer.parseInt(scanner.nextLine());
        System.out.print("Procesador: "); String procesador = scanner.nextLine();
        System.out.print("RAM (GB): "); int ram = Integer.parseInt(scanner.nextLine());
        System.out.print("Almacenamiento (GB): "); int almacenamiento = Integer.parseInt(scanner.nextLine());
        System.out.print("Tarjeta Gráfica: "); String tarjeta = scanner.nextLine();
        System.out.print("Tipo (Laptop/Desktop): "); String tipo = scanner.nextLine();

        Computador comp = new Computador(codigo, marca, modelo, precio, stock, garantia,
                procesador, ram, almacenamiento, tarjeta, tipo);
        gestor.agregarProducto(comp);
    }

    private static void agregarSmartphone() {
        System.out.println("\n--- Nuevo Smartphone ---");
        System.out.print("Código: "); String codigo = scanner.nextLine();
        System.out.print("Marca: "); String marca = scanner.nextLine();
        System.out.print("Modelo: "); String modelo = scanner.nextLine();
        System.out.print("Precio: "); double precio = Double.parseDouble(scanner.nextLine());
        System.out.print("Stock: "); int stock = Integer.parseInt(scanner.nextLine());
        System.out.print("Garantía (meses): "); int garantia = Integer.parseInt(scanner.nextLine());
        System.out.print("Sistema Operativo: "); String so = scanner.nextLine();
        System.out.print("Pantalla (pulgadas): "); double pantalla = Double.parseDouble(scanner.nextLine());
        System.out.print("Cámara (MP): "); int camara = Integer.parseInt(scanner.nextLine());
        System.out.print("Batería (mAh): "); int bateria = Integer.parseInt(scanner.nextLine());
        System.out.print("¿5G? (true/false): "); boolean es5G = Boolean.parseBoolean(scanner.nextLine());

        Smartphone phone = new Smartphone(codigo, marca, modelo, precio, stock, garantia,
                so, pantalla, camara, bateria, es5G);
        gestor.agregarProducto(phone);
    }

    private static void buscarProducto() throws ProductoNoEncontradoException {
        System.out.print("\nCódigo: ");
        Producto p = gestor.buscarProductoPorCodigo(scanner.nextLine());
        p.mostrarEspecificaciones();
    }

    private static void actualizarPrecio() throws ProductoNoEncontradoException {
        System.out.print("\nCódigo: "); String codigo = scanner.nextLine();
        System.out.print("Nuevo precio: "); double precio = Double.parseDouble(scanner.nextLine());
        gestor.actualizarPrecioProducto(codigo, precio);
    }

    private static void eliminarProducto() throws ProductoNoEncontradoException {
        System.out.print("\nCódigo: "); String codigo = scanner.nextLine();
        System.out.print("¿Seguro? (S/N): ");
        if (scanner.nextLine().equalsIgnoreCase("S")) {
            gestor.eliminarProducto(codigo);
        }
    }

    private static void filtrarPorMarca() {
        System.out.print("\nMarca: ");
        List<Producto> productos = gestor.filtrarPorMarca(scanner.nextLine());
        if (productos.isEmpty()) {
            System.out.println("No hay productos de esa marca");
        } else {
            for (Producto p : productos) System.out.println(p);
        }
    }

    private static void menuClientes() {
        System.out.println("\n=== CLIENTES ===");
        System.out.println("1. Registrar cliente");
        System.out.println("2. Buscar cliente");
        System.out.println("3. Listar todos");
        System.out.print("Opción: ");

        int opcion = leerOpcion();
        switch (opcion) {
            case 1: registrarCliente(); break;
            case 2: buscarCliente(); break;
            case 3: gestor.listarClientes(); break;
        }
    }

    private static void registrarCliente() {
        System.out.println("\n--- Nuevo Cliente ---");
        System.out.print("ID: "); String id = scanner.nextLine();
        System.out.print("Nombre: "); String nombre = scanner.nextLine();
        System.out.print("Teléfono: "); String telefono = scanner.nextLine();
        System.out.print("Email: "); String email = scanner.nextLine();
        System.out.print("Tipo (Regular/VIP/Premium): "); String tipo = scanner.nextLine();

        gestor.agregarCliente(new Cliente(id, nombre, telefono, email, tipo));
    }

    private static void buscarCliente() {
        System.out.print("\nID: ");
        Cliente c = gestor.buscarCliente(scanner.nextLine());
        if (c != null) c.mostrarInformacion();
        else System.out.println("Cliente no encontrado");
    }

    private static void registrarEmpleado() {
        System.out.println("\n--- Nuevo Empleado ---");
        System.out.print("ID: "); String id = scanner.nextLine();
        System.out.print("Nombre: "); String nombre = scanner.nextLine();
        System.out.print("Teléfono: "); String telefono = scanner.nextLine();
        System.out.print("Email: "); String email = scanner.nextLine();
        System.out.print("Cargo: "); String cargo = scanner.nextLine();
        System.out.print("Salario: "); double salario = Double.parseDouble(scanner.nextLine());
        System.out.print("Turno: "); String turno = scanner.nextLine();

        gestor.agregarEmpleado(new Empleado(id, nombre, telefono, email, cargo, salario, turno));
    }

    private static void realizarVenta() throws ProductoNoEncontradoException, StockInsuficienteException {
        System.out.println("\n=== NUEVA VENTA ===");
        System.out.print("ID Cliente: "); String idCliente = scanner.nextLine();
        System.out.print("ID Vendedor: "); String idVendedor = scanner.nextLine();
        
        List<String> productos = new ArrayList<>();
        boolean agregar = true;
        while (agregar) {
            System.out.print("Código producto: "); productos.add(scanner.nextLine());
            System.out.print("¿Otro producto? (S/N): "); agregar = scanner.nextLine().equalsIgnoreCase("S");
        }
        
        System.out.print("Método pago: "); String metodo = scanner.nextLine();
        gestor.realizarVenta(idCliente, idVendedor, productos, metodo);
    }

    private static int leerOpcion() {
        try {
            return Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            return -1;
        }
    }
}