package co.edu.sena.semanas.ProyectoFinal.src.com.techstore.servicio;

import co.edu.sena.semanas.ProyectoFinal.src.com.techstore.modelo.*;
import co.edu.sena.semanas.ProyectoFinal.src.com.techstore.excepciones.*;
import java.util.*;

public class GestorTienda {
    private Map<String, Producto> productosPorCodigo;
    private Map<String, Cliente> clientesPorId;
    private Map<String, Empleado> empleadosPorId;
    private List<Venta> historialVentas;
    private int contadorVentas;

    public GestorTienda() {
        this.productosPorCodigo = new HashMap<>();
        this.clientesPorId = new HashMap<>();
        this.empleadosPorId = new HashMap<>();
        this.historialVentas = new ArrayList<>();
        this.contadorVentas = 1;
        cargarDatosPrueba();
    }

    public void agregarProducto(Producto producto) {
        if (productosPorCodigo.containsKey(producto.getCodigo())) {
            throw new IllegalArgumentException("Producto ya existe: " + producto.getCodigo());
        }
        productosPorCodigo.put(producto.getCodigo(), producto);
        System.out.println("✓ Producto agregado: " + producto.getMarca() + " " + producto.getModelo());
    }

    public Producto buscarProductoPorCodigo(String codigo) throws ProductoNoEncontradoException {
        Producto producto = productosPorCodigo.get(codigo);
        if (producto == null) {
            throw new ProductoNoEncontradoException("Producto no encontrado: " + codigo);
        }
        return producto;
    }

    public void listarTodosLosProductos() {
        if (productosPorCodigo.isEmpty()) {
            System.out.println("No hay productos.");
            return;
        }
        System.out.println("\n=== INVENTARIO (" + productosPorCodigo.size() + " productos) ===");
        for (Producto p : productosPorCodigo.values()) {
            p.mostrarEspecificaciones();
            System.out.println("---");
        }
    }

    public void actualizarPrecioProducto(String codigo, double nuevoPrecio) throws ProductoNoEncontradoException {
        Producto producto = buscarProductoPorCodigo(codigo);
        producto.setPrecio(nuevoPrecio);
        System.out.println("✓ Precio actualizado");
    }

    public void eliminarProducto(String codigo) throws ProductoNoEncontradoException {
        Producto producto = buscarProductoPorCodigo(codigo);
        productosPorCodigo.remove(codigo);
        System.out.println("✓ Producto eliminado: " + producto.getMarca());
    }

    public List<Producto> filtrarPorMarca(String marca) {
        List<Producto> resultado = new ArrayList<>();
        for (Producto p : productosPorCodigo.values()) {
            if (p.getMarca().equalsIgnoreCase(marca)) {
                resultado.add(p);
            }
        }
        return resultado;
    }

    public void agregarCliente(Cliente cliente) {
        if (clientesPorId.containsKey(cliente.getId())) {
            throw new IllegalArgumentException("Cliente ya existe: " + cliente.getId());
        }
        clientesPorId.put(cliente.getId(), cliente);
        System.out.println("✓ Cliente registrado: " + cliente.getNombre());
    }

    public Cliente buscarCliente(String id) {
        return clientesPorId.get(id);
    }

    public void listarClientes() {
        if (clientesPorId.isEmpty()) {
            System.out.println("No hay clientes.");
            return;
        }
        System.out.println("\n=== CLIENTES (" + clientesPorId.size() + ") ===");
        for (Cliente c : clientesPorId.values()) {
            c.mostrarInformacion();
            System.out.println("---");
        }
    }

    public void agregarEmpleado(Empleado empleado) {
        if (empleadosPorId.containsKey(empleado.getId())) {
            throw new IllegalArgumentException("Empleado ya existe: " + empleado.getId());
        }
        empleadosPorId.put(empleado.getId(), empleado);
        System.out.println("✓ Empleado registrado: " + empleado.getNombre());
    }

    public Empleado buscarEmpleado(String id) {
        return empleadosPorId.get(id);
    }

    public void realizarVenta(String idCliente, String idVendedor, List<String> codigosProductos, String metodoPago) 
            throws ProductoNoEncontradoException, StockInsuficienteException {
        Cliente cliente = buscarCliente(idCliente);
        Empleado vendedor = buscarEmpleado(idVendedor);
        
        if (cliente == null) throw new IllegalArgumentException("Cliente no encontrado");
        if (vendedor == null) throw new IllegalArgumentException("Vendedor no encontrado");
        
        String codigoVenta = "V-" + String.format("%05d", contadorVentas++);
        Venta venta = new Venta(codigoVenta, cliente, vendedor, metodoPago);
        
        for (String codigo : codigosProductos) {
            Producto producto = buscarProductoPorCodigo(codigo);
            if (!producto.hayDisponibilidad()) {
                throw new StockInsuficienteException("Sin stock: " + producto.getMarca());
            }
            venta.agregarProducto(producto);
            producto.reducirStock(1);
        }
        
        cliente.agregarPuntos(venta.calcularPuntosGanados());
        vendedor.registrarVenta();
        historialVentas.add(venta);
        
        System.out.println("\n VENTA REALIZADA");
        venta.mostrarDetalle();
    }

    public void listarVentas() {
        if (historialVentas.isEmpty()) {
            System.out.println("No hay ventas.");
            return;
        }
        System.out.println("\n=== VENTAS (" + historialVentas.size() + ") ===");
        for (Venta v : historialVentas) {
            System.out.println(v);
        }
    }

    public void mostrarEstadisticas() {
        System.out.println("\n=== ESTADÍSTICAS TECHSTORE ===");
        System.out.println("Productos: " + productosPorCodigo.size());
        System.out.println("Clientes: " + clientesPorId.size());
        System.out.println("Empleados: " + empleadosPorId.size());
        System.out.println("Ventas: " + historialVentas.size());
        
        if (!historialVentas.isEmpty()) {
            double total = 0;
            for (Venta v : historialVentas) {
                total += v.getTotalVenta();
            }
            System.out.println("Total facturado: $" + String.format("%,.2f", total));
            System.out.println("Promedio venta: $" + String.format("%,.2f", total / historialVentas.size()));
        }
    }

    private void cargarDatosPrueba() {
        agregarProducto(new Computador("COMP001", "Apple", "MacBook Pro M3", 9500000, 3, 12,
            "Apple M3", 16, 512, "Integrada M3", "Laptop"));
        agregarProducto(new Computador("COMP002", "HP", "Pavilion 15", 2800000, 8, 12,
            "Intel i5", 8, 256, "Intel Iris", "Laptop"));
        agregarProducto(new Smartphone("PHONE001", "Samsung", "Galaxy S24", 5200000, 10, 24,
            "Android 14", 6.8, 200, 5000, true));
        agregarProducto(new Smartphone("PHONE002", "iPhone", "15 Pro", 7800000, 2, 12,
            "iOS 17", 6.7, 48, 4422, true));

        agregarCliente(new Cliente("C001", "María González", "3101234567", "maria@email.com", "VIP"));
        agregarCliente(new Cliente("C002", "Carlos Rodríguez", "3209876543", "carlos@email.com", "Regular"));

        agregarEmpleado(new Empleado("E001", "Pedro Sánchez", "3001112233", "pedro@techstore.com",
            "Vendedor", 2500000, "Mañana"));
        agregarEmpleado(new Empleado("E002", "Laura Torres", "3004445566", "laura@techstore.com",
            "Técnico", 2800000, "Tarde"));
    }
}