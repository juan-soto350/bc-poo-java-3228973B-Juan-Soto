package co.edu.sena.semanas.ProyectoFinal.src.com.techstore.modelo;




/**
 * Clase que representa un empleado de TechStore.
 * Hereda de Persona.
 */
public class Empleado extends Persona {
    private String cargo;
    private double salario;
    private String turno;
    private int ventasRealizadas;

    /**
    * Constructor de Empleado.
    */
    public Empleado(String id, String nombre, String telefono, String email, 
                    String cargo, double salario, String turno) {
        super(id, nombre, telefono, email);
        
        if (salario < 0) {
            throw new IllegalArgumentException("El salario no puede ser negativo");
        }
        
        this.cargo = cargo;
        this.salario = salario;
        this.turno = turno;
        this.ventasRealizadas = 0;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        if (salario < 0) {
            throw new IllegalArgumentException("El salario no puede ser negativo");
        }
        this.salario = salario;
    }

    public String getTurno() {
        return turno;
    }

    public void setTurno(String turno) {
        this.turno = turno;
    }

    public int getVentasRealizadas() {
        return ventasRealizadas;
    }

    public void registrarVenta() {
        this.ventasRealizadas++;
    }

    @Override
    public void mostrarInformacion() {
        System.out.println("=== INFORMACIÓN DEL EMPLEADO ===");
        System.out.println(super.toString());
        System.out.println("Cargo: " + cargo);
        System.out.println("Salario: $" + String.format("%,.2f", salario));
        System.out.println("Turno: " + turno);
        System.out.println("Ventas Realizadas: " + ventasRealizadas);
    }
}