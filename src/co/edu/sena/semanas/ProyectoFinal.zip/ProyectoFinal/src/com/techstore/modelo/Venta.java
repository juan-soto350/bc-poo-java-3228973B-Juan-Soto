package co.edu.sena.semanas.ProyectoFinal.src.com.techstore.modelo;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

// Clase que representa una venta realizada en TechStore.
 
public class Venta {
    private String codigoVenta;
    private Cliente cliente;
    private Empleado vendedor;
    private List<Producto> productos;
    private LocalDateTime fechaVenta;
    private double totalVenta;
    private String metodoPago; // "Efectivo", "Tarjeta", "Transferencia"

    // Constructor de Venta.
     
    public Venta(String codigoVenta, Cliente cliente, Empleado vendedor, String metodoPago) {
        if (codigoVenta == null || codigoVenta.trim().isEmpty()) {
            throw new IllegalArgumentException("El código de venta no puede estar vacío");
        }
        if (cliente == null) {
            throw new IllegalArgumentException("El cliente no puede ser nulo");
        }
        if (vendedor == null) {
            throw new IllegalArgumentException("El vendedor no puede ser nulo");
        }
        
        this.codigoVenta = codigoVenta;
        this.cliente = cliente;
        this.vendedor = vendedor;
        this.metodoPago = metodoPago;
        this.productos = new ArrayList<>();
        this.fechaVenta = LocalDateTime.now();
        this.totalVenta = 0.0;
    }

    // Agrega un producto a la venta.
     
    public void agregarProducto(Producto producto) {
        if (producto != null) {
            productos.add(producto);
            calcularTotal();
        }
    }

    // Calcula el total de la venta aplicando descuentos.
     
    private void calcularTotal() {
        totalVenta = 0.0;
        for (Producto producto : productos) {
            totalVenta += producto.calcularPrecioFinal(cliente.getDescuentoAplicable());
        }
    }

    // Calcula los puntos ganados por el cliente.
     
    public int calcularPuntosGanados() {
        return (int) (totalVenta / 10000);
    }

    public String getCodigoVenta() {
        return codigoVenta;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public Empleado getVendedor() {
        return vendedor;
    }

    public List<Producto> getProductos() {
        return new ArrayList<>(productos);
    }

    public LocalDateTime getFechaVenta() {
        return fechaVenta;
    }

    public double getTotalVenta() {
        return totalVenta;
    }

    public String getMetodoPago() {
        return metodoPago;
    }

    // Muestra el detalle completo de la venta.
     
    public void mostrarDetalle() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
        
        System.out.println("\n========================================");
        System.out.println("         FACTURA DE VENTA - TECHSTORE");
        System.out.println("========================================");
        System.out.println("Código Venta: " + codigoVenta);
        System.out.println("Fecha: " + fechaVenta.format(formatter));
        System.out.println("----------------------------------------");
        System.out.println("Cliente: " + cliente.getNombre());
        System.out.println("Tipo: " + cliente.getTipoCliente());
        System.out.println("Descuento: " + (cliente.getDescuentoAplicable() * 100) + "%");
        System.out.println("----------------------------------------");
        System.out.println("Vendedor: " + vendedor.getNombre());
        System.out.println("----------------------------------------");
        System.out.println("PRODUCTOS:");
        
        for (int i = 0; i < productos.size(); i++) {
            Producto p = productos.get(i);
            double precioFinal = p.calcularPrecioFinal(cliente.getDescuentoAplicable());
            System.out.println((i + 1) + ". " + p.getMarca() + " " + p.getModelo());
            System.out.println("   Precio: $" + String.format("%,.2f", p.getPrecio()));
            System.out.println("   Con descuento: $" + String.format("%,.2f", precioFinal));
        }
        
        System.out.println("----------------------------------------");
        System.out.println("TOTAL: $" + String.format("%,.2f", totalVenta));
        System.out.println("Método de pago: " + metodoPago);
        System.out.println("Puntos ganados: " + calcularPuntosGanados());
        System.out.println("========================================\n");
    }

    @Override
    public String toString() {
        return "Venta " + codigoVenta + " - Cliente: " + cliente.getNombre() + 
               " - Total: $" + String.format("%,.2f", totalVenta);
    }
}