package co.edu.sena.semanas.ProyectoFinal.src.com.techstore.modelo;

// Interface que define el comportamiento de cotización de productos.


public interface Cotizable {
    
    // Calcula el precio final aplicando un descuento.
    double calcularPrecioFinal(double descuento);
}