# Proyecto Final: Sistema TechStore

## 👤 Información del Estudiante

| Campo | Valor |
|-------|-------|
| **Nombre** | Juan Esteban Soto Perez |
| **Ficha** | 3228973B |
| **Dominio** | Tienda de Tecnología "TechStore" |
| **Fecha** | 13/12/2025 |

---

## 📝 Descripción del Sistema

Sistema de gestión para una tienda de tecnología que permite administrar inventario de computadores y smartphones, gestionar clientes con diferentes niveles de membresía (Regular, VIP, Premium), controlar empleados y procesar ventas con descuentos automáticos según el tipo de cliente.

---

## 🏗️ Estructura del Proyecto

```
com.techstore/
├── modelo/           - Persona, Cliente, Empleado, Producto, Computador, Smartphone, Venta, Cotizable
├── servicio/         - GestorTienda
├── excepciones/      - ProductoNoEncontradoException, StockInsuficienteException
└── Main.java
```

---

## 🧬 Conceptos POO Aplicados

### Encapsulación
- Atributos private con validaciones
- Validaciones: IDs no vacíos, emails válidos, precios/stock no negativos

### Herencia
- **Persona** → Cliente, Empleado
- **Producto** → Computador, Smartphone

### Polimorfismo
- Sobrescritura: `mostrarInformacion()`, `mostrarEspecificaciones()`
- Colecciones polimórficas: `Map<String, Producto>` contiene Computadores y Smartphones

### Abstracción
- Clases abstractas: Persona, Producto
- Interface: Cotizable

### Excepciones
- `ProductoNoEncontradoException` - Producto no existe
- `StockInsuficienteException` - Sin stock disponible

### Colecciones
- `HashMap<String, Producto>` - Búsqueda O(1) por código
- `HashMap<String, Cliente>` - Búsqueda O(1) por ID
- `ArrayList<Venta>` - Historial cronológico

---

## 📋 Funcionalidades

- ✅ CRUD de productos (Computador/Smartphone)
- ✅ Gestión de clientes con tipos de membresía
- ✅ Registro de empleados
- ✅ Sistema de ventas con descuentos automáticos
- ✅ Filtros por marca
- ✅ Estadísticas generales
- ✅ Historial de ventas

---

## 🚀 Cómo Ejecutar

### Desde Terminal
```bash
cd proyecto-final
javac -d bin src/com/techstore/*/*.java src/com/techstore/*.java
java -cp bin com.techstore.Main
```

### Desde IntelliJ IDEA
1. Abrir proyecto
2. Marcar `src/` como Source Root
3. Run `Main.java`

---

## 🎓 Reflexión

**Desafío principal:** Diseñar jerarquías de clases que evitaran código duplicado usando herencia efectiva.

**Aprendizaje clave:** Entender que la abstracción y el polimorfismo permiten crear código reutilizable y escalable.

**Mejora futura:** Agregar persistencia de datos en base de datos o archivos.

---

*Proyecto Final - Bootcamp POO Java - SENA - 2025*